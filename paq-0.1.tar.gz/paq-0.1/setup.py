from setuptools import setup, find_packages

setup(
    name='paq',
    version='0.1',
    packages=['paq'],
    install_requires=[])

# python setup.py sdist bdist_wheel