from .question2 import *


__all__ = [
        'generate',
        'get_metric',
        'learn',
        'predict',
        'target_statistics',
        'features_statistics',
        'correlation',
        'statistics',
        'print_correlations'
    ]
__version__ = "0.1.0"
__author__ = 'Yousef Taheri'
__credits__ = 'SITA'